// url semaforo
const api_url = 
      "https://xompasssuiteadminstg.z20.web.core.windows.net/semaphore.json";

// Funcion que hace el request al json del semaforo
async function semaforo_request(url){
    const response = await fetch(url);
    var data = await response.json();
    let states = {};
    
    // Visualizacion de los datos
    //console.log(data.currentLightColor);
    for (var i = 0; i < data.lights.length; i++) {
      console.log(data.lights[i].color);
      console.log(data.lights[i].duration);
      if (data.lights[i].color == "red"){
      states[data.lights[i].color] = {duration: data.lights[i].duration, next: "orange"};
      }
      else if (data.lights[i].color == "orange"){
        states[data.lights[i].color] = {duration: data.lights[i].duration, next: "green"};
      }
      else if (data.lights[i].color == "green"){
        states[data.lights[i].color] = {duration: data.lights[i].duration, next: "red"};
      }
    };
  
let semaphore = (state,el)=>{ 
  let setNewState = (newState)=>{
    state = newState;
    //console.log('O semaphore está',states[state].color);
    el.className = 'semaphore '+ state;
    setTimeout(()=>{setNewState(states[state].next)}, states[state].duration*1000)  
  };
  return setNewState;
} 

let divs = document.getElementsByClassName('semaphore');
console.log(divs.length)
let sem01 = semaphore('red',divs[0]);
let sem02 = semaphore('orange',divs[1]);
let sem03 = semaphore('green',divs[2]);

     
if (data.currentLightColor == "red"){
sem01('red');
}
if (data.currentLightColor == "orange"){
sem01('orange');
}
if (data.currentLightColor == "green"){
sem01('green')
}
  
  
  
  
    // Cambio de estados
    
  
};

// Llamada funcion
semaforo_request(api_url);
//semaforo_request(api_url);